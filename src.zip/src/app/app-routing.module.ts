import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
<<<<<<< HEAD
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { ManagerComponent } from './manager/manager.component';
import { AuthGaurdService } from './service/auth-guard.service';

const routes: Routes = [

  {path:'admin',component:AdminComponent,canActivate:[AuthGaurdService]},
  {path:'login',component:LoginComponent},
  {path:'manager', component:ManagerComponent,canActivate:[AuthGaurdService]}
=======
import { ResourceComponent } from './resource/resource.component';
import {CourseComponent } from './course/course.component'

const routes: Routes = [
  {path:'resource',component:ResourceComponent},
  {path:'course',component:CourseComponent}
>>>>>>> 93f88241dde8df38303612f02d0b922db907acbb
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})



export class AppRoutingModule {

 }
 
