import { AnonymousSubject } from 'rxjs/internal/Subject';

export class Resource {
        resourceId:any;
        resourceName:any;
        resourceDescription:any;
        capacity:any;
        fees:any;
        status:any;
        access:any;
        resourceType:any;
}
