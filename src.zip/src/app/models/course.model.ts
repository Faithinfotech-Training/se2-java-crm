export class Course {
    courseId: any;
    courseName: any;
    description: any;
    fees: any;
    scoreCriteria: any;
    ageCriteria: any;
    duration: any;
    domain: any;
    access: any;
    status: any;
    qualifications: any;
}